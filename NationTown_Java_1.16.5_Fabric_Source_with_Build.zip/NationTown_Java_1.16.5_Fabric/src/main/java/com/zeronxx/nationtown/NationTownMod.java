package com.zeronxx.nationtown;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateManager;
import net.minecraft.nbt.CompoundTag;

public class NationTownMod implements ModInitializer {
    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> dispatcher.register(
            CommandManager.literal("nt")
                .then(CommandManager.literal("help").executes(ctx -> {
                    ctx.getSource().sendFeedback(new LiteralText("§6[NationTown] §eKomutlar: /nt balance, /nt pay <oyuncu> <miktar>, /nt town create <isim>, /nt nation create <isim>"), false);
                    return 1;
                }))
                .then(CommandManager.literal("balance").executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayer();
                    NationTownData data = NationTownData.get(ctx.getSource());
                    int money = data.getMoney(p.getUuidAsString());
                    p.sendMessage(new LiteralText("§6[NationTown] §eBakiyen: §a" + money + " coin"), false);
                    return 1;
                }))
                .then(CommandManager.literal("pay")
                    .then(CommandManager.argument("oyuncu", StringArgumentType.word())
                        .then(CommandManager.argument("miktar", IntegerArgumentType.integer(1))
                            .executes(ctx -> {
                                ServerCommandSource source = ctx.getSource();
                                ServerPlayerEntity from = source.getPlayer();
                                String targetName = StringArgumentType.getString(ctx, "oyuncu");
                                int amount = IntegerArgumentType.getInteger(ctx, "miktar");
                                ServerPlayerEntity target = source.getMinecraftServer().getPlayerManager().getPlayer(targetName);
                                if (target == null) { source.sendError(new LiteralText("Oyuncu çevrimiçi değil.")); return 0; }
                                if (target.getUuid().equals(from.getUuid())) { source.sendError(new LiteralText("Kendine para gönderemezsin.")); return 0; }
                                NationTownData data = NationTownData.get(source);
                                String fromId = from.getUuidAsString(), toId = target.getUuidAsString();
                                if (data.getMoney(fromId) < amount) { source.sendError(new LiteralText("Yeterli paran yok.")); return 0; }
                                data.setMoney(fromId, data.getMoney(fromId) - amount);
                                data.setMoney(toId, data.getMoney(toId) + amount);
                                from.sendMessage(new LiteralText("§a" + target.getEntityName() + " oyuncusuna " + amount + " coin gönderdin."), false);
                                target.sendMessage(new LiteralText("§a" + from.getEntityName() + " sana " + amount + " coin gönderdi."), false);
                                return 1;
                            }))))
                .then(CommandManager.literal("town").then(CommandManager.literal("create")
                    .then(CommandManager.argument("isim", StringArgumentType.word()).executes(ctx -> {
                        ServerPlayerEntity p = ctx.getSource().getPlayer();
                        String id = p.getUuidAsString();
                        String name = StringArgumentType.getString(ctx, "isim");
                        NationTownData data = NationTownData.get(ctx.getSource());
                        if (data.getTown(id) != null) { ctx.getSource().sendError(new LiteralText("Zaten bir town'un var.")); return 0; }
                        if (data.getMoney(id) < 500) { ctx.getSource().sendError(new LiteralText("Town kurmak için 500 coin gerekli.")); return 0; }
                        if (data.townExists(name)) { ctx.getSource().sendError(new LiteralText("Bu isimde bir town zaten var.")); return 0; }
                        data.setMoney(id, data.getMoney(id) - 500);
                        data.createTown(name, id, p.getBlockPos());
                        data.setTown(id, name);
                        p.sendMessage(new LiteralText("§aTown kuruldu: §e" + name + " §7(-500 coin)"), false);
                        return 1;
                    }))))
                .then(CommandManager.literal("nation").then(CommandManager.literal("create")
                    .then(CommandManager.argument("isim", StringArgumentType.word()).executes(ctx -> {
                        ServerPlayerEntity p = ctx.getSource().getPlayer();
                        String id = p.getUuidAsString();
                        String name = StringArgumentType.getString(ctx, "isim");
                        NationTownData data = NationTownData.get(ctx.getSource());
                        if (data.getNation(id) != null) { ctx.getSource().sendError(new LiteralText("Zaten bir nation'un var.")); return 0; }
                        if (data.getTown(id) == null) { ctx.getSource().sendError(new LiteralText("Önce /nt town create <isim> ile town kur.")); return 0; }
                        if (data.nationExists(name)) { ctx.getSource().sendError(new LiteralText("Bu isimde bir nation zaten var.")); return 0; }
                        data.createNation(name, id, data.getTown(id));
                        data.setNation(id, name);
                        p.sendMessage(new LiteralText("§aNation kuruldu: §e" + name), false);
                        return 1;
                    }))))
        ));
    }

    static class NationTownData extends PersistentState {
        private final CompoundTag root;
        private NationTownData() { super("nationtown_data"); root = new CompoundTag(); root.put("players", new CompoundTag()); root.put("towns", new CompoundTag()); root.put("nations", new CompoundTag()); }
        private NationTownData(CompoundTag tag) { super("nationtown_data"); root = tag; if (!root.contains("players")) root.put("players", new CompoundTag()); if (!root.contains("towns")) root.put("towns", new CompoundTag()); if (!root.contains("nations")) root.put("nations", new CompoundTag()); }
        static NationTownData get(ServerCommandSource source) {
            PersistentStateManager manager = source.getMinecraftServer().getOverworld().getPersistentStateManager();
            return manager.getOrCreate(NationTownData::new, NationTownData::new, "nationtown_data");
        }
        @Override public CompoundTag writeNbt(CompoundTag tag) { tag.put("players", root.getCompound("players").copy()); tag.put("towns", root.getCompound("towns").copy()); tag.put("nations", root.getCompound("nations").copy()); return tag; }
        int getMoney(String id) { CompoundTag players = root.getCompound("players"); CompoundTag p = players.getCompound(id); if (!players.contains(id)) { p.putInt("money", 1000); players.put(id, p); markDirty(); } return p.getInt("money"); }
        void setMoney(String id, int amount) { CompoundTag players = root.getCompound("players"); CompoundTag p = players.getCompound(id); p.putInt("money", amount); players.put(id, p); markDirty(); }
        String getTown(String id) { return root.getCompound("players").getCompound(id).getString("town"); }
        String getNation(String id) { return root.getCompound("players").getCompound(id).getString("nation"); }
        void setTown(String id, String town) { CompoundTag players=root.getCompound("players"), p=players.getCompound(id); p.putString("town",town); if(!p.contains("money"))p.putInt("money",1000); players.put(id,p); markDirty(); }
        void setNation(String id, String nation) { CompoundTag players=root.getCompound("players"), p=players.getCompound(id); p.putString("nation",nation); players.put(id,p); markDirty(); }
        boolean townExists(String name) { return root.getCompound("towns").contains(name); }
        boolean nationExists(String name) { return root.getCompound("nations").contains(name); }
        void createTown(String name, String owner, BlockPos pos) { CompoundTag t=new CompoundTag(); t.putString("owner",owner); t.putInt("x",pos.getX()); t.putInt("y",pos.getY()); t.putInt("z",pos.getZ()); root.getCompound("towns").put(name,t); markDirty(); }
        void createNation(String name, String owner, String town) { CompoundTag n=new CompoundTag(); n.putString("owner",owner); n.putString("capital",town); root.getCompound("nations").put(name,n); markDirty(); }
    }
}
