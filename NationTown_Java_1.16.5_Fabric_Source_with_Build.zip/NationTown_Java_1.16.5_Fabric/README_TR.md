# NationTown Java Port — Minecraft 1.16.5 / Fabric

Bu paket, NationTown Bedrock v4 dosyasından yola çıkılarak hazırlanan **erken Java portu kaynak projesidir**. Henüz tamamlanmış veya test edilmiş bir `.jar` değildir.

## İlk prototipte bulunanlar
- `/nt help`
- `/nt balance` — oyuncu ilk kez kaydedildiğinde 1000 coin
- `/nt pay <oyuncu> <miktar>` — çevrimiçi oyuncuya para gönderme
- `/nt town create <isim>` — 500 coin karşılığında town kurma
- `/nt nation create <isim>` — town sahibi olduktan sonra nation kurma
- Ekonomi, town ve nation verileri dünya kaydına `PersistentState` ile yazılır.

## Önemli sınırlar
- Bu **tam port değildir**. Bedrock scriptindeki savaş, ordu, diplomasi, vergiler, işler, seçimler, özel menüler, harita ve diğer sistemler henüz uygulanmadı.
- Bedrock dünyasındaki kayıtlar Java'ya otomatik taşınmaz. Bu prototip Java dünyasında ayrı kayıt tutar.
- Kod henüz Gradle ile derlenip oyunda test edilmedi; API/mapping uyumsuzlukları çıkabilir.
- Test hedefi: Minecraft Java 1.16.5 + Fabric Loader 0.11.7 + Fabric API 0.42.0+1.16, Java 8.

## Derleme
Bilgisayarda JDK 8 ve Gradle 6.x ile proje klasöründe `gradle build` çalıştırılabilir. Başarılı derleme sonrası dosya `build/libs/` içinde oluşur. Android/ZalithLauncher oyunu çalıştırmak içindir; bu kaynak projeyi tek başına `.jar` haline getirmez.

## Otomatik `.jar` derleme (GitHub Actions)

Bu proje bu sohbet ortaminda derlenip test edilmedi. ZIP'i GitHub'da yeni bir depoya yukleyip `Actions` sekmesinden `Build NationTown Fabric 1.16.5` is akisini calistirabilirsin. Akis Java 8 ve Gradle 6.9.4 kurup `gradle build` calistirir; basarili olursa `NationTown-Fabric-1.16.5` isimli artifact icinde `.jar` olusturur. Derleme hatasi cikarsa workflow logundaki ilk hata duzeltilmelidir. Bu yontem internet baglantisi olan GitHub sunucularinda bagimliliklari indirir; kendi cihazinda Gradle kurman gerekmez.
